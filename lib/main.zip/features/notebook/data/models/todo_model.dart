// lib/features/todo/data/models/todo_model.dart

import 'package:hive/hive.dart';

@HiveType(typeId: 0)
class Todo {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String description;

  @HiveField(3)
  final DateTime createdAt;

  @HiveField(4)
  final DateTime lastEdited;

  @HiveField(5)
  final DateTime? dueDate;

  @HiveField(6)
  final bool isCompleted;

  @HiveField(7)
  final bool isImportant;

  @HiveField(8)
  final bool isArchived;

  @HiveField(9)
  final List<String> tags;

  @HiveField(10)
  final int priority; // 0: Low, 1: Medium, 2: High

  @HiveField(11)
  final List<Subtask> subtasks;

  @HiveField(12)
  final int? reminderMinutes;

  @HiveField(13)
  final String? category;

  @HiveField(14)
  final int? estimatedMinutes;

  @HiveField(15)
  final int? progressPercentage;

  const Todo({
    required this.id,
    required this.title,
    required this.description,
    required this.createdAt,
    required this.lastEdited,
    this.dueDate,
    this.isCompleted = false,
    this.isImportant = false,
    this.isArchived = false,
    this.tags = const [],
    this.priority = 1,
    this.subtasks = const [],
    this.reminderMinutes,
    this.category,
    this.estimatedMinutes,
    this.progressPercentage,
  });

  factory Todo.create({
    required String title,
    String description = '',
    DateTime? dueDate,
    int priority = 1,
    String? category,
  }) {
    final now = DateTime.now();
    return Todo(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: title.trim(),
      description: description.trim(),
      createdAt: now,
      lastEdited: now,
      dueDate: dueDate,
      priority: priority,
      category: category,
      progressPercentage: 0,
    );
  }

  Todo copyWith({
    String? title,
    String? description,
    DateTime? dueDate,
    bool? isCompleted,
    bool? isImportant,
    bool? isArchived,
    List<String>? tags,
    int? priority,
    List<Subtask>? subtasks,
    int? reminderMinutes,
    String? category,
    int? estimatedMinutes,
    int? progressPercentage,
  }) {
    return Todo(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      createdAt: createdAt,
      lastEdited: DateTime.now(),
      dueDate: dueDate ?? this.dueDate,
      isCompleted: isCompleted ?? this.isCompleted,
      isImportant: isImportant ?? this.isImportant,
      isArchived: isArchived ?? this.isArchived,
      tags: tags ?? this.tags,
      priority: priority ?? this.priority,
      subtasks: subtasks ?? this.subtasks,
      reminderMinutes: reminderMinutes ?? this.reminderMinutes,
      category: category ?? this.category,
      estimatedMinutes: estimatedMinutes ?? this.estimatedMinutes,
      progressPercentage: progressPercentage ?? this.progressPercentage,
    );
  }

  double get completionPercentage {
    if (subtasks.isEmpty) return isCompleted ? 100 : (progressPercentage ?? 0).toDouble();
    if (subtasks.isEmpty) return isCompleted ? 100 : 0;
    final completedSubtasks = subtasks.where((s) => s.isCompleted).length;
    return (completedSubtasks / subtasks.length) * 100;
  }

  String get priorityLabel {
    switch (priority) {
      case 0: return 'Low';
      case 2: return 'High';
      default: return 'Medium';
    }
  }

  Color get priorityColor {
    switch (priority) {
      case 0: return Colors.green;
      case 2: return Colors.red;
      default: return Colors.orange;
    }
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'createdAt': createdAt.toIso8601String(),
    'lastEdited': lastEdited.toIso8601String(),
    'dueDate': dueDate?.toIso8601String(),
    'isCompleted': isCompleted,
    'isImportant': isImportant,
    'isArchived': isArchived,
    'tags': tags,
    'priority': priority,
    'subtasks': subtasks.map((s) => s.toJson()).toList(),
    'reminderMinutes': reminderMinutes,
    'category': category,
    'estimatedMinutes': estimatedMinutes,
    'progressPercentage': progressPercentage,
  };

  factory Todo.fromJson(Map<String, dynamic> json) {
    return Todo(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String? ?? '',
      createdAt: DateTime.parse(json['createdAt']),
      lastEdited: json['lastEdited'] != null
          ? DateTime.parse(json['lastEdited'])
          : DateTime.parse(json['createdAt']),
      dueDate: json['dueDate'] != null ? DateTime.parse(json['dueDate']) : null,
      isCompleted: json['isCompleted'] ?? false,
      isImportant: json['isImportant'] ?? false,
      isArchived: json['isArchived'] ?? false,
      tags: (json['tags'] as List?)?.cast<String>() ?? [],
      priority: json['priority'] ?? 1,
      subtasks: (json['subtasks'] as List?)
          ?.map((s) => Subtask.fromJson(s))
          .toList() ?? [],
      reminderMinutes: json['reminderMinutes'],
      category: json['category'],
      estimatedMinutes: json['estimatedMinutes'],
      progressPercentage: json['progressPercentage'],
    );
  }
}

@HiveType(typeId: 1)
class Subtask {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final bool isCompleted;

  Subtask({
    required this.id,
    required this.title,
    this.isCompleted = false,
  });

  Subtask copyWith({
    String? title,
    bool? isCompleted,
  }) {
    return Subtask(
      id: id,
      title: title ?? this.title,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'isCompleted': isCompleted,
  };

  factory Subtask.fromJson(Map<String, dynamic> json) {
    return Subtask(
      id: json['id'] as String,
      title: json['title'] as String,
      isCompleted: json['isCompleted'] ?? false,
    );
  }
}