// lib/features/todo/data/repositories/todo_repository.dart

import '../../../../core/services/local_storage_service.dart';
import '../models/todo_model.dart';

class TodoRepository {
  final LocalStorageService _storageService;

  TodoRepository(this._storageService);

  Future<List<Todo>> getAllTodos() async {
    final todosData = await _storageService.getAllNotes(); // Reusing storage
    return todosData.map((data) => Todo.fromJson(data)).toList();
  }

  Future<Todo?> getTodoById(String id) async {
    final todoData = await _storageService.getNote(id);
    if (todoData != null) {
      return Todo.fromJson(todoData);
    }
    return null;
  }

  Future<void> saveTodo(Todo todo) async {
    await _storageService.saveNote(todo.toJson());
  }

  Future<void> deleteTodo(String id) async {
    await _storageService.deleteNote(id);
  }

  Future<void> updateTodo(Todo todo) async {
    await _storageService.saveNote(todo.toJson());
  }

  Future<List<Todo>> getTodayTasks() async {
    final todos = await getAllTodos();
    final today = DateTime.now();
    return todos.where((todo) {
      if (todo.dueDate == null) return false;
      return todo.dueDate!.year == today.year &&
          todo.dueDate!.month == today.month &&
          todo.dueDate!.day == today.day &&
          !todo.isCompleted &&
          !todo.isArchived;
    }).toList();
  }

  Future<List<Todo>> getUpcomingTasks() async {
    final todos = await getAllTodos();
    final today = DateTime.now();
    return todos.where((todo) {
      if (todo.dueDate == null) return false;
      return todo.dueDate!.isAfter(today) &&
          !todo.isCompleted &&
          !todo.isArchived;
    }).toList();
  }

  Future<List<Todo>> getOverdueTasks() async {
    final todos = await getAllTodos();
    final today = DateTime.now();
    return todos.where((todo) {
      if (todo.dueDate == null) return false;
      return todo.dueDate!.isBefore(today) &&
          !todo.isCompleted &&
          !todo.isArchived;
    }).toList();
  }

  Future<List<Todo>> getImportantTasks() async {
    final todos = await getAllTodos();
    return todos.where((todo) => todo.isImportant && !todo.isArchived).toList();
  }

  Future<List<Todo>> searchTodos(String query) async {
    final allTodos = await getAllTodos();
    if (query.isEmpty) return allTodos;
    final lowerQuery = query.toLowerCase();
    return allTodos.where((todo) {
      return todo.title.toLowerCase().contains(lowerQuery) ||
          todo.description.toLowerCase().contains(lowerQuery);
    }).toList();
  }
}
