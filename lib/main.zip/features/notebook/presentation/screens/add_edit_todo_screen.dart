// lib/features/todo/presentation/screens/todo_detail_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../data/models/todo_model.dart';
import '../controllers/todo_controller.dart';
import 'add_edit_todo_screen.dart';
import 'package:get/get.dart';

class TodoDetailScreen extends StatefulWidget {
  final Todo todo;

  const TodoDetailScreen({Key? key, required this.todo}) : super(key: key);

  @override
  State<TodoDetailScreen> createState() => _TodoDetailScreenState();
}

class _TodoDetailScreenState extends State<TodoDetailScreen> {
  late TodoController _controller;
  late Todo _currentTodo;

  @override
  void initState() {
    super.initState();
    _currentTodo = widget.todo;
    _controller = Get.find<TodoController>();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Task Details'),
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(
              _currentTodo.isImportant ? Icons.flag : Icons.flag_outlined,
            ),
            onPressed: () => _toggleImportant(),
            color: _currentTodo.isImportant ? Colors.red : null,
          ),
          IconButton(icon: const Icon(Icons.edit), onPressed: _editTodo),
          PopupMenuButton(
            itemBuilder: (context) => [
              const PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.archive),
                    SizedBox(width: 8),
                    Text('Archive'),
                  ],
                ),
              ),
              const PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.delete, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Delete', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
            onSelected: (value) {
              if (value == 'archive') {
                _toggleArchive();
              } else if (value == 'delete') {
                _deleteTodo();
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Checkbox(
                  value: _currentTodo.isCompleted,
                  onChanged: (_) => _toggleComplete(),
                  activeColor: const Color(0xFF6366F1),
                ),
                Expanded(
                  child: Text(
                    _currentTodo.title,
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      decoration: _currentTodo.isCompleted
                          ? TextDecoration.lineThrough
                          : null,
                      color: _currentTodo.isCompleted
                          ? Colors.grey
                          : Colors.black87,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _buildMetadata(),
            const SizedBox(height: 24),
            if (_currentTodo.description.isNotEmpty) ...[
              const Text(
                'Description',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                _currentTodo.description,
                style: const TextStyle(fontSize: 16, height: 1.5),
              ),
              const SizedBox(height: 24),
            ],
            if (_currentTodo.subtasks.isNotEmpty) ...[
              const Text(
                'Subtasks',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              ..._currentTodo.subtasks.map(
                (subtask) => CheckboxListTile(
                  value: subtask.isCompleted,
                  title: Text(
                    subtask.title,
                    style: TextStyle(
                      decoration: subtask.isCompleted
                          ? TextDecoration.lineThrough
                          : null,
                    ),
                  ),
                  onChanged: (value) => _toggleSubtask(subtask),
                  activeColor: const Color(0xFF6366F1),
                ),
              ),
              const SizedBox(height: 24),
            ],
            if (_currentTodo.tags.isNotEmpty) ...[
              const Text(
                'Tags',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: _currentTodo.tags
                    .map((tag) => Chip(label: Text('#$tag')))
                    .toList(),
              ),
              const SizedBox(height: 24),
            ],
            _buildProgressSection(),
          ],
        ),
      ),
      floatingActionButton: _currentTodo.isCompleted
          ? null
          : FloatingActionButton.extended(
              onPressed: _editTodo,
              icon: const Icon(Icons.edit),
              label: const Text('Edit Task'),
              backgroundColor: const Color(0xFF6366F1),
            ),
    );
  }

  Widget _buildMetadata() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildMetadataRow(
              Icons.priority_high,
              'Priority',
              _currentTodo.priorityLabel,
              _currentTodo.priorityColor,
            ),
            const Divider(),
            if (_currentTodo.dueDate != null)
              _buildMetadataRow(
                Icons.event,
                'Due Date',
                _formatDateTime(_currentTodo.dueDate!),
                _getDueDateColor(),
              ),
            if (_currentTodo.dueDate != null) const Divider(),
            if (_currentTodo.category != null)
              _buildMetadataRow(
                Icons.category,
                'Category',
                _currentTodo.category!,
                Colors.blue,
              ),
            if (_currentTodo.category != null) const Divider(),
            if (_currentTodo.estimatedMinutes != null)
              _buildMetadataRow(
                Icons.timer,
                'Estimated Time',
                '${_currentTodo.estimatedMinutes} minutes',
                Colors.orange,
              ),
            if (_currentTodo.estimatedMinutes != null) const Divider(),
            _buildMetadataRow(
              Icons.access_time,
              'Created',
              _formatDateTime(_currentTodo.createdAt),
              Colors.grey,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetadataRow(
    IconData icon,
    String label,
    String value,
    Color color,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(width: 16),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
          const Spacer(),
          Text(value, style: TextStyle(color: color)),
        ],
      ),
    );
  }

  Widget _buildProgressSection() {
    final progress = _currentTodo.completionPercentage;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Progress',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        LinearProgressIndicator(
          value: progress / 100,
          backgroundColor: Colors.grey[200],
          valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF6366F1)),
          minHeight: 10,
        ),
        const SizedBox(height: 8),
        Text(
          '${progress.toInt()}% complete',
          style: const TextStyle(color: Colors.grey),
        ),
      ],
    );
  }

  Future<void> _toggleComplete() async {
    final updated = _currentTodo.copyWith(
      isCompleted: !_currentTodo.isCompleted,
    );
    await _controller.updateTodo(updated);
    setState(() {
      _currentTodo = updated;
    });
  }

  Future<void> _toggleImportant() async {
    final updated = _currentTodo.copyWith(
      isImportant: !_currentTodo.isImportant,
    );
    await _controller.updateTodo(updated);
    setState(() {
      _currentTodo = updated;
    });
  }

  Future<void> _toggleArchive() async {
    final updated = _currentTodo.copyWith(isArchived: true);
    await _controller.updateTodo(updated);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _toggleSubtask(Subtask subtask) async {
    final index = _currentTodo.subtasks.indexWhere((s) => s.id == subtask.id);
    final newSubtasks = List<Subtask>.from(_currentTodo.subtasks);
    newSubtasks[index] = subtask.copyWith(isCompleted: !subtask.isCompleted);

    final updated = _currentTodo.copyWith(subtasks: newSubtasks);
    await _controller.updateTodo(updated);
    setState(() {
      _currentTodo = updated;
    });
  }

  Future<void> _editTodo() async {
    final result = await Navigator.push<Todo>(
      context,
      MaterialPageRoute(builder: (_) => AddEditTodoScreen(todo: _currentTodo)),
    );
    if (result != null) {
      setState(() {
        _currentTodo = result;
      });
    }
  }

  Future<void> _deleteTodo() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Task'),
        content: Text(
          'Are you sure you want to delete "${_currentTodo.title}"?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _controller.deleteTodoById(_currentTodo.id);
      if (mounted) Navigator.pop(context);
    }
  }

  Color _getDueDateColor() {
    if (_currentTodo.isCompleted) return Colors.grey;
    if (_currentTodo.dueDate!.isBefore(DateTime.now())) return Colors.red;
    if (_currentTodo.dueDate!.difference(DateTime.now()).inDays <= 1)
      return Colors.orange;
    return Colors.green;
  }

  String _formatDateTime(DateTime date) {
    return '${date.day}/${date.month}/${date.year} at ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }
}
