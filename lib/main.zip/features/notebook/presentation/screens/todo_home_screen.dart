// lib/features/todo/presentation/screens/todo_home_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:get/get.dart';
import '../controllers/todo_controller.dart';
import '../../data/repositories/todo_repository.dart';
import '../../data/models/todo_model.dart';
import 'add_edit_todo_screen.dart';
import 'todo_detail_screen.dart';
import '../../../core/services/local_storage_service.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';

class TodoHomeScreen extends StatefulWidget {
  const TodoHomeScreen({Key? key}) : super(key: key);

  @override
  _TodoHomeScreenState createState() => _TodoHomeScreenState();
}

class _TodoHomeScreenState extends State<TodoHomeScreen>
    with SingleTickerProviderStateMixin {
  bool _isSearching = false;
  String _searchQuery = '';
  String _selectedFilter = 'All';
  bool _showStats = true;

  final List<String> _filters = [
    'All',
    'Today',
    'Upcoming',
    'Important',
    'Completed',
  ];

  late Future<TodoController> _controllerFuture;
  final AuthController _authController = Get.find<AuthController>();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  Timer? _searchDebounceTimer;

  @override
  void initState() {
    super.initState();
    _controllerFuture = _initializeController();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _searchDebounceTimer?.cancel();
    _animationController.dispose();
    super.dispose();
  }

  Future<TodoController> _initializeController() async {
    final localStorage = LocalStorageService();
    await localStorage.init();
    final repository = TodoRepository(localStorage);
    final controller = TodoController(repository);
    await controller.loadTodos();
    return controller;
  }

  void _onSearchChanged(String query) {
    if (_searchDebounceTimer?.isActive ?? false) {
      _searchDebounceTimer!.cancel();
    }
    _searchDebounceTimer = Timer(const Duration(milliseconds: 300), () {
      setState(() {
        _searchQuery = query;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<TodoController>(
      future: _controllerFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Color(0xFF6366F1),
                    ),
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Loading your tasks...',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            ),
          );
        }

        if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.error_outline,
                      size: 64,
                      color: Colors.red,
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Error loading tasks',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${snapshot.error}',
                    style: TextStyle(color: Colors.grey[600]),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    onPressed: () {
                      setState(() {
                        _controllerFuture = _initializeController();
                      });
                    },
                    icon: const Icon(Icons.refresh),
                    label: const Text('Retry'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6366F1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        }

        final controller = snapshot.data!;

        return FadeTransition(
          opacity: _fadeAnimation,
          child: ChangeNotifierProvider.value(
            value: controller,
            child: Scaffold(
              backgroundColor: Colors.grey[50],
              appBar: _buildAppBar(),
              body: _buildBody(controller),
              floatingActionButton: _buildFloatingActionButton(controller),
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.white,
      foregroundColor: Colors.black87,
      title: _isSearching
          ? _buildSearchBar()
          : const Text(
              "My Tasks",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 28,
                color: Colors.black87,
                letterSpacing: -0.5,
              ),
            ),
      actions: [
        if (!_isSearching) ...[
          IconButton(
            icon: Icon(_showStats ? Icons.stats : Icons.stats_outlined),
            onPressed: () {
              setState(() {
                _showStats = !_showStats;
              });
              HapticFeedback.lightImpact();
            },
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              setState(() {
                _isSearching = true;
              });
            },
          ),
        ],
        const SizedBox(width: 8),
      ],
      bottom: _buildFilterChips(),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              autofocus: true,
              onChanged: _onSearchChanged,
              decoration: const InputDecoration(
                hintText: 'Search tasks...',
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _isSearching = false;
                _searchQuery = '';
              });
            },
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildFilterChips() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(50),
      child: Container(
        height: 50,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(bottom: BorderSide(color: Colors.grey[100]!)),
        ),
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: _filters.length,
          itemBuilder: (context, index) {
            final filter = _filters[index];
            final isSelected = _selectedFilter == filter;
            return Padding(
              padding: const EdgeInsets.only(right: 12),
              child: FilterChip(
                label: Text(filter),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    _selectedFilter = filter;
                  });
                  HapticFeedback.lightImpact();
                },
                backgroundColor: Colors.grey[100],
                selectedColor: const Color(0xFF6366F1).withOpacity(0.1),
                checkmarkColor: const Color(0xFF6366F1),
                labelStyle: TextStyle(
                  color: isSelected
                      ? const Color(0xFF6366F1)
                      : Colors.grey[700],
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                  fontSize: 13,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildBody(TodoController controller) {
    return Consumer<TodoController>(
      builder: (context, todoController, child) {
        if (todoController.isLoading) {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF6366F1)),
            ),
          );
        }

        var filteredTodos = _getFilteredTodos(todoController);

        if (_searchQuery.isNotEmpty) {
          filteredTodos = filteredTodos.where((todo) {
            return todo.title.toLowerCase().contains(
                  _searchQuery.toLowerCase(),
                ) ||
                todo.description.toLowerCase().contains(
                  _searchQuery.toLowerCase(),
                );
          }).toList();
        }

        if (filteredTodos.isEmpty) {
          return _buildEmptyState();
        }

        return RefreshIndicator(
          onRefresh: () async {
            await todoController.loadTodos();
          },
          color: const Color(0xFF6366F1),
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: filteredTodos.length,
            itemBuilder: (context, index) {
              final todo = filteredTodos[index];
              return _buildTodoCard(todo, todoController);
            },
          ),
        );
      },
    );
  }

  List<Todo> _getFilteredTodos(TodoController controller) {
    switch (_selectedFilter) {
      case 'Today':
        return controller.todos.where((t) {
          if (t.dueDate == null) return false;
          final today = DateTime.now();
          return t.dueDate!.year == today.year &&
              t.dueDate!.month == today.month &&
              t.dueDate!.day == today.day &&
              !t.isCompleted &&
              !t.isArchived;
        }).toList();
      case 'Upcoming':
        return controller.todos.where((t) {
          if (t.dueDate == null) return false;
          return t.dueDate!.isAfter(DateTime.now()) &&
              !t.isCompleted &&
              !t.isArchived;
        }).toList();
      case 'Important':
        return controller.todos
            .where((t) => t.isImportant && !t.isArchived)
            .toList();
      case 'Completed':
        return controller.todos
            .where((t) => t.isCompleted && !t.isArchived)
            .toList();
      default:
        return controller.todos.where((t) => !t.isArchived).toList();
    }
  }

  Widget _buildTodoCard(Todo todo, TodoController controller) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.grey[200]!),
      ),
      child: InkWell(
        onTap: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => TodoDetailScreen(todo: todo)),
          );
          if (result != null) {
            setState(() {});
          }
        },
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Checkbox(
                    value: todo.isCompleted,
                    onChanged: (_) => controller.toggleComplete(todo),
                    activeColor: const Color(0xFF6366F1),
                  ),
                  Expanded(
                    child: Text(
                      todo.title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        decoration: todo.isCompleted
                            ? TextDecoration.lineThrough
                            : null,
                        color: todo.isCompleted ? Colors.grey : Colors.black87,
                      ),
                    ),
                  ),
                  if (todo.isImportant)
                    Icon(Icons.flag, color: Colors.red, size: 20),
                  PopupMenuButton(
                    icon: Icon(Icons.more_vert, color: Colors.grey[400]),
                    itemBuilder: (context) => [
                      PopupMenuItem(
                        child: Row(
                          children: [
                            Icon(
                              todo.isImportant ? Icons.flag_off : Icons.flag,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              todo.isImportant
                                  ? 'Remove Important'
                                  : 'Mark Important',
                            ),
                          ],
                        ),
                        onTap: () => controller.toggleImportant(todo),
                      ),
                      PopupMenuItem(
                        child: const Row(
                          children: [
                            Icon(Icons.archive, size: 18),
                            SizedBox(width: 8),
                            Text('Archive'),
                          ],
                        ),
                        onTap: () => controller.toggleArchive(todo),
                      ),
                      PopupMenuItem(
                        child: const Row(
                          children: [
                            Icon(Icons.delete, size: 18, color: Colors.red),
                            SizedBox(width: 8),
                            Text('Delete', style: TextStyle(color: Colors.red)),
                          ],
                        ),
                        onTap: () => _showDeleteDialog(controller, todo),
                      ),
                    ],
                  ),
                ],
              ),
              if (todo.description.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  todo.description,
                  style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
              const SizedBox(height: 12),
              Row(
                children: [
                  if (todo.dueDate != null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: _getDueDateColor(todo).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.event,
                            size: 12,
                            color: _getDueDateColor(todo),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            _formatDate(todo.dueDate!),
                            style: TextStyle(
                              fontSize: 11,
                              color: _getDueDateColor(todo),
                            ),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: todo.priorityColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      todo.priorityLabel,
                      style: TextStyle(
                        fontSize: 11,
                        color: todo.priorityColor,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  if (todo.subtasks.isNotEmpty) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.checklist,
                            size: 12,
                            color: Colors.blue[700],
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '${todo.subtasks.where((s) => s.isCompleted).length}/${todo.subtasks.length}',
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.blue[700],
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
              if (todo.estimatedMinutes != null) ...[
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: todo.completionPercentage / 100,
                  backgroundColor: Colors.grey[200],
                  valueColor: const AlwaysStoppedAnimation<Color>(
                    Color(0xFF6366F1),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${todo.completionPercentage.toInt()}% complete • ${todo.estimatedMinutes} min est.',
                  style: TextStyle(fontSize: 10, color: Colors.grey[500]),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Color _getDueDateColor(Todo todo) {
    if (todo.isCompleted) return Colors.grey;
    if (todo.dueDate!.isBefore(DateTime.now())) return Colors.red;
    if (todo.dueDate!.difference(DateTime.now()).inDays <= 1)
      return Colors.orange;
    return Colors.green;
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _selectedFilter == 'Completed'
                ? Icons.check_circle_outline
                : Icons.task_outlined,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            _selectedFilter == 'Completed'
                ? 'No completed tasks'
                : _selectedFilter == 'Important'
                ? 'No important tasks'
                : _selectedFilter == 'Today'
                ? 'No tasks for today'
                : _selectedFilter == 'Upcoming'
                ? 'No upcoming tasks'
                : 'No tasks yet',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _selectedFilter == 'All'
                ? 'Tap the + button to create your first task'
                : 'Try a different filter',
            style: TextStyle(color: Colors.grey[500]),
          ),
          if (_selectedFilter == 'All') const SizedBox(height: 24),
          if (_selectedFilter == 'All')
            ElevatedButton.icon(
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AddEditTodoScreen()),
                );
                if (result != null) {
                  final controller = Provider.of<TodoController>(
                    context,
                    listen: false,
                  );
                  controller.addTodo(result);
                }
              },
              icon: const Icon(Icons.add),
              label: const Text('Create Task'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6366F1),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFloatingActionButton(TodoController controller) {
    return FloatingActionButton.extended(
      onPressed: () async {
        HapticFeedback.mediumImpact();
        final result = await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const AddEditTodoScreen()),
        );
        if (result != null) {
          controller.addTodo(result);
        }
      },
      icon: const Icon(Icons.add),
      label: const Text('New Task'),
      elevation: 2,
      backgroundColor: const Color(0xFF6366F1),
      foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
    );
  }

  void _showDeleteDialog(TodoController controller, Todo todo) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Task'),
        content: Text('Are you sure you want to delete "${todo.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              controller.deleteTodoById(todo.id);
              Navigator.pop(context);
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text('Task deleted')));
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    if (date.year == now.year &&
        date.month == now.month &&
        date.day == now.day) {
      return 'Today';
    }
    if (date.year == now.year &&
        date.month == now.month &&
        date.day == now.day + 1) {
      return 'Tomorrow';
    }
    return '${date.day}/${date.month}/${date.year}';
  }
}
