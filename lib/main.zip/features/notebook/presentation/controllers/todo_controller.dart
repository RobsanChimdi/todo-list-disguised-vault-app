// lib/features/todo/presentation/controllers/todo_controller.dart

import 'package:flutter/material.dart';
import '../../data/repositories/todo_repository.dart';
import '../../data/models/todo_model.dart';

class TodoController extends ChangeNotifier {
  final TodoRepository _repository;

  List<Todo> _todos = [];
  bool _isLoading = false;
  String? _error;

  TodoController(this._repository) {
    loadTodos();
  }

  List<Todo> get todos => _todos;
  List<Todo> get activeTodos =>
      _todos.where((t) => !t.isCompleted && !t.isArchived).toList();
  List<Todo> get completedTodos =>
      _todos.where((t) => t.isCompleted && !t.isArchived).toList();
  List<Todo> get archivedTodos => _todos.where((t) => t.isArchived).toList();

  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> loadTodos() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _todos = await _repository.getAllTodos();
    } catch (e) {
      _error = e.toString();
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> addTodo(Todo todo) async {
    await _repository.saveTodo(todo);
    await loadTodos();
  }

  Future<void> updateTodo(Todo todo) async {
    await _repository.updateTodo(todo);
    await loadTodos();
  }

  Future<void> deleteTodoById(String id) async {
    await _repository.deleteTodo(id);
    await loadTodos();
  }

  Future<void> toggleComplete(Todo todo) async {
    final updated = todo.copyWith(isCompleted: !todo.isCompleted);
    await updateTodo(updated);
  }

  Future<void> toggleImportant(Todo todo) async {
    final updated = todo.copyWith(isImportant: !todo.isImportant);
    await updateTodo(updated);
  }

  Future<void> toggleArchive(Todo todo) async {
    final updated = todo.copyWith(isArchived: !todo.isArchived);
    await updateTodo(updated);
  }

  Future<void> updateProgress(Todo todo, int progress) async {
    final updated = todo.copyWith(progressPercentage: progress);
    if (progress == 100) {
      final completedUpdate = updated.copyWith(isCompleted: true);
      await updateTodo(completedUpdate);
    } else {
      await updateTodo(updated);
    }
  }

  Future<List<Todo>> search(String query) async {
    return await _repository.searchTodos(query);
  }
}
